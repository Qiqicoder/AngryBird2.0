from cmu_graphics import *

#-----------MODULE 1 Background & Obstacles-------------------------------------
class obstacles:
    def __init__(self, recLeft, recTop, recWidth, recHeight, reccolor):
        self.recLeft = recLeft
        self.recTop = recTop
        self.recWidth = recWidth
        self.recHeight = recHeight
        self.reccolor = reccolor

def onAppStart(app):
    #make one of the obstacles moving
    app.obstacles = [ obstacles(300, 700, 800, 20, 'red'),
                 obstacles(0, 800, 250, 20, 'red'),
                 obstacles(200, 900, 350, 20, 'pink'),
                 obstacles(100, 500, 100, 20, 'darkSlateGray'),
                 obstacles(0, 350, 500, 20, 'darkSlateGray'),
                 obstacles(200, 550, 100, 20, 'darkSlateGray'),
                 obstacles(300, 600, 300, 20, 'darkSlateGray'),
               ]
    
def redrawAll(app):
    drawLabel('Obstacles Example', 120, 50, size=25)
    drawLabel('Obstacles need to collide with the characters', 258, 80, size=25)
    # draw the obstacles:
    for obstacles in app.obstacles:
        drawRect(obstacles.recLeft, obstacles.recTop, obstacles.recWidth, obstacles.recHeight, fill=obstacles.reccolor)
        #drawLabel(str(obstacles.count), obstacles.rectLeft, obstacles.rectTop)

def distance(x0, y0, x1, y1):
    return ((x1 - x0)**2 + (y1 - y0)**2)**0.5

def main():
    runApp(width=1000, height=1000)

if __name__ == '__main__':
    main()