from cmu_graphics import *

#-----------MODULE 2 Button--------------------------------------------------

class Button:
    def ButtonFunction(app):
        app.music = not app.music  # mute button

